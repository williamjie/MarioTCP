/*
 * function.h
 *	
 *  Date: 2013-3-1
 *  Author: feng jianhua (johan fong)
 *  Mail: 56683216@qq.com
 *
 *  �޸ļ�¼��
 */

#ifndef FUNCTON_H_
#define FUNCTON_H_

#include "mario/mario.h"

sint32 login(CONN* c);
sint32 logout(CONN* c);

#endif /* FUNCTON_H_ */
